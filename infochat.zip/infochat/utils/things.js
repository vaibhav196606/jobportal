const moment = require('moment');
function fm(username,text){
	return{
		username,
		text,
		time: moment().format('h:mm a')
	}
};
module.export = fm;