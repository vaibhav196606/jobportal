const express = require("express");
const path = require("path");
const http = require("http");
const app = express();
const tz = require('moment-timezone');
const PORT = 3000 || process.env.PORT;
const socketio = require("socket.io");
const server = http.createServer(app);
const io = socketio(server);
const {userJoin, getCurrentUser, userLeave, userRoom} = require("./utils/users");
app.use(express.static(path.join(__dirname,'public')));
const moment = require('moment');
function fm(username,text){
	return{
		username,
		text,
		time: moment().tz('Asia/Kolkata').format('h:mm a')
	}
};
app.get('/job-display',function(req,res){
	var data = [{
		'company' : 'Sigmastore.in',
		'position' : 'Web Development',
		'shortd' : 'Highly experienced webdeveloper having knowledge of NodeJs, JavaScript and ReactJs is must',
		'pay' : 500000,
		'exp' : 2,
		'location' : 'Warangal'
	},{
		'company' : 'Microsoft',
		'position' : 'Software Develpopment',
		'shortd' : 'SDE-II is requied in hyderabad urgently and should be experienced in OOPS, DBMS and Data Structures',
		'pay' : 1500000,
		'exp' : 1,
		'location' : 'Hyderabad'
	},{
		'company' : 'ITC',
		'position' : 'Chemical Engineer',
		'shortd' : 'For paper making plant we needed a project manager having degree in Chemical engineering and relevent 						experince',
		'pay' : 2200000,
		'exp' : 3,
		'location' : 'Kolkata'
	}];
	res.render('job-display.ejs',{data : data});
})

io.on('connection',socket=>{
	
	socket.on('joinChat',({username,room})=>{
			if(username === undefined || username==''){
				username = "Stranger";
			}
		    if(room === undefined || room==''){
				room = "random";
			}
			const user = userJoin(socket.id,username,room);
			console.log(user);
			socket.join(user.room);
			//to user only
			socket.emit("message" , fm('Chat Bot',' Welcome to info-chat '+user.username));
			//to everyone except user
			socket.broadcast.to(user.room).emit("message" , fm('Chat Bot',user.username+' has joined the chat'));
			io.to(user.room).emit('userR',{
				room : user.room,
				users: userRoom(user.room)
			});
		
	});
	
	socket.on('chatMessage',msg=>{
		const user = getCurrentUser(socket.id);
		console.log(msg);
		io.to(user.room).emit("message",fm(user.username,msg));  
	})
	socket.on("disconnect",()=>{
		//to everyone
		const user = userLeave(socket.id);
		if(user){
			
			io.to(user.room).emit("message",fm('Chat Bot',user.username+ ' has left the room'));
			io.to(user.room).emit('userR',{
			room : user.room,
			users: userRoom(user.room)
		});
		}
		
		console.log("disconnect");
	});
	
});


server.listen(PORT, ()=>console.log('server running on port ' + PORT));
