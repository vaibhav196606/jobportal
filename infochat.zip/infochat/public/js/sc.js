const chatForm = document.getElementById("textmsg");
const socket = io();

const {username, room} = Qs.parse(location.search,{
	ignoreQueryPrefix : true
	
});

socket.emit('joinChat',{username,room});



socket.on("message", message=>{
	console.log(message);
	outMsg(message);
})
socket.on("userR",({room,users})=>{
	console.log(room);
	showRoom(room);
	showUsers(users);
});

chatForm.addEventListener('submit',e =>{
	e.preventDefault();
	const msg = e.target.elements.mss.value;
	socket.emit('chatMessage',msg);
	$( '#textmsg' ).each(function(){
    	this.reset();
		});
});
function outMsg(message){
	const div = document.createElement('div');
	div.classList.add('container');
	div.classList.add('msg');
	div.innerHTML = '<div class="name"><span>'+message.username+' </span><span id="date">'+message.time+'</span> :</div><div class="msg-body">'+message.text+'</div>';
	document.getElementById("xyz").appendChild(div);
	var objDiv = document.getElementById("xyz");
	objDiv.scrollTop = objDiv.scrollHeight;
}
function showRoom(room){
	var c= document.getElementById("chat-room");
	c.textContent = room;
	
}
function showUsers(users){
	p = "";
	for(var i=0 ; i<users.length ; i++){
		p = p+ '<p><i class="fas fa-user"></i> '+users[i].username+'</p>';
		
	}
	var j =document.getElementById("lis");
	j.innerHTML = p;
	const nu = document.getElementById("aun");
	const nub = document.getElementById("aunr");
	nu.textContent = users.length;
	nub.textContent = users.length;
};